#!/bin/bash

sphinx-apidoc -F -o docs . --separate
